const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 10000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.post("/start", (req, res) => {
  const { token, groupId, groupName, nickname } = req.body;
  console.log("🚀 Bot Started with data =>", { token, groupId, groupName, nickname });
  // TODO: Add your FB automation logic here (group rename, nickname change)
  res.send("✅ Bot started successfully with given details!");
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
